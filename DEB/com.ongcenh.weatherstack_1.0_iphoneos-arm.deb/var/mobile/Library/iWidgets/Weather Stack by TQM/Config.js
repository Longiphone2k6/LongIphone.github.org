var scle = 0.85; // Tuỳ chỉnh kích cỡ
var twentyfourhour = true; // On of Off
var pad = true; // On of Off
var textcolor = "white"; // Tuỳ chỉnh mã màu hiển thị.
var QuangMinh1 = "tqm2"; // "tqm1" of "tqm2"
var QuangMinh2 = "tqm1"; // "tqm1" of "tqm2"
